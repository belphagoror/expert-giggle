# SPDX-License-Identifier: Apache-2.0
import sys, json, re, os

SEV_INFO, SEV_WARN, SEV_ERROR = "INFO","WARN","ERROR"

def log(findings, sev, msg, ctx):
    findings.append({"sev":sev, "msg":msg, "ctx":ctx})

def word_count(s):
    return len([w for w in re.split(r"\s+", s.strip()) if w])

def load_canonical_verbs():
    path = os.path.join(os.path.dirname(__file__), "canonical_verbs.json")
    try:
        return set(json.load(open(path,"r",encoding="utf-8"))["verbs"])
    except Exception:
        return set()

def rule_main_profile(findings, doc):
    level = doc.get("l")
    if level not in ("L2","L3"):
        return
    verbs = load_canonical_verbs()
    if "beats_tbl" in doc and doc.get("beats"):
        log(findings, SEV_WARN, "beats present alongside beats_tbl; omit beats in L3", {})
    for b in doc.get("beats", []):
        s = b.get("evt")
        if isinstance(s, str) and word_count(s) > 12:
            log(findings, SEV_ERROR, f"evt exceeds 12-word cap at level {level}", {"beat":b.get("id")})
        a = (b.get("actn") or {}).get("a")
        if a and verbs and a not in verbs:
            log(findings, SEV_ERROR, f"actn.a not in canonical verb set: {a}", {"beat": b.get("id")})

def rule_l4_caps(findings, doc):
    if doc.get("l") != "L4":
        return
    themes = doc.get("themes") or []
    if len(themes) > 8:
        log(findings, SEV_ERROR, f"L4 themes exceed cap (8): {len(themes)}", {})
    quotes = doc.get("quotes") or []
    if len(quotes) > 40:
        log(findings, SEV_ERROR, f"L4 quotes exceed cap (40): {len(quotes)}", {})
    pool_q = (doc.get("dict") or {}).get("q") or []
    for q in quotes:
        qsi = q.get("q_si")
        if isinstance(qsi, int) and 0 <= qsi < len(pool_q):
            s = pool_q[qsi]
            if isinstance(s, str) and word_count(s) > 12:
                log(findings, SEV_ERROR, "L4 quote exceeds 12-word cap", q)

def rule_l5_coverage(findings, doc):
    if doc.get("l") != "L5":
        return
    tm = doc.get("text_map") or {}
    cov = tm.get("coverage"); tol = tm.get("loss_tolerance")
    if cov is None or tol is None:
        log(findings, SEV_ERROR, "L5 requires text_map.coverage and text_map.loss_tolerance", {}); return
    if not (0 <= cov <= 1 and 0 <= tol <= 1):
        log(findings, SEV_ERROR, "coverage/loss_tolerance must be in [0,1]", {})
    if cov < (1 - tol):
        log(findings, SEV_ERROR, f"coverage {cov} < 1 - loss_tolerance {1-tol}", {})

def rule_pool_threshold(findings, doc):
    pool = (doc.get("dict") or {}).get("s") or []
    if not pool: return
    refs = [0]*len(pool)
    def bump(i):
        if isinstance(i, int) and 0 <= i < len(pool):
            refs[i]+=1
    for b in doc.get("beats", []):
        bump(b.get("evt_si"))
    for arr_name in ("chars","ents","mysteries"):
        for o in doc.get(arr_name, []) or []:
            bump(o.get("n_si") if arr_name!="mysteries" else o.get("q_si"))
    few = [i for i,c in enumerate(refs) if c==1]
    if few:
        log(findings, SEV_WARN, f"{len(few)} pooled strings referenced only once (consider not pooling one-offs)", {})

def rule_beats_tbl_columns(findings, doc):
    tbl = doc.get("beats_tbl")
    if not isinstance(tbl, dict): return
    cols = tbl.get("cols")
    want = ["id","act","evt_si","p","a","u","i","loc","when"]
    if cols != want:
        log(findings, SEV_ERROR, f"beats_tbl.cols must exactly equal {want}, got {cols}", {})

def analyze(findings, doc):
    pass

def validate(paths):
    ok = True
    for path in paths:
        findings = []
        with open(path, "r", encoding="utf-8") as f:
            doc = json.load(f)
        rule_main_profile(findings, doc)
        rule_l4_caps(findings, doc)
        rule_l5_coverage(findings, doc)
        rule_pool_threshold(findings, doc)
        rule_beats_tbl_columns(findings, doc)
        errs = [x for x in findings if x["sev"]=="ERROR"]
        print(f"# {path}")
        for x in findings:
            print(f"- {x['sev']}: {x['msg']} :: {x['ctx']}")
        if errs: ok = False
    return 0 if ok else 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: sbf_validate.py <file1.json> [file2.json ...]"); sys.exit(2)
    sys.exit(validate(sys.argv[1:]))
