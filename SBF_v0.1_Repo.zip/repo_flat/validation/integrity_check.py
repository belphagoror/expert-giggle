# SPDX-License-Identifier: Apache-2.0
import sys, json, re
from pathlib import Path

ROOT = (lambda p: next((q for i in range(5) for q in [p.parents[i]] if (q/'docs').exists() and (q/'schema').exists()), p.parent.parent))(Path(__file__).resolve()).resolve().parents[2]
PROJ = ROOT / "Project"
FAILS = []

def fail(msg): FAILS.append(msg); print(f"[FAIL] {msg}")
def ok(msg): print(f"[OK] {msg}")
def read(p: Path): 
    try: return p.read_text(encoding="utf-8")
    except Exception as e: fail(f"Cannot read {p}: {e}"); return ""

def _norm(t: str) -> str:
    return (t.replace('\u2011','-').replace('\u2012','-').replace('\u2013','-').replace('\u2014','-').replace('\u2015','-')).lower()

def check_exists(path: str, min_bytes: int = 10):
    p = ROOT / path
    if not p.exists(): fail(f"Missing {path}"); return None
    if p.stat().st_size < min_bytes: fail(f"Truncated/very small {path} ({p.stat().st_size} bytes)")
    else: ok(f"Exists: {path} ({p.stat().st_size} bytes)")
    return p

def check_markers(path: str, markers: list[str]):
    p = check_exists(path, 32)
    if not p: return
    s = _norm(read(p))
    for m in markers:
        if _norm(m) not in s: fail(f"Marker '{m}' not found in {path}")
        else: ok(f"Marker '{m}' found in {path}")

def main():
    check_markers("docs/VISION.md", ["Vision", "lossy-first"])
    check_markers("docs/Story_Blueprint_Format_GFM.md", ["Levels (Profiles)", "L4", "L5", "Main (lossy)"])
    check_markers("docs/SBF_v0.1_Spec.md", ["Normative Specification", "Conformance", "Levels", "Canonical verbs"])

    check_markers("Project/README.md", ["docs/VISION.md", "docs/Story_Blueprint_Format_GFM.md"])
    check_markers("Project/CODEX.md", ["Standing instructions", "Kickoff prompt"])
    check_markers("Project/DEVELOPING.md", ["Conventions", "L2/L3"])

    sp = check_exists("schema/sbf_schema_v0_1.json", 64)
    if sp:
        sch = json.loads(sp.read_text(encoding="utf-8"))
        levels = sch["properties"]["l"]["enum"]
        if not all(x in levels for x in ["L4","L5"]): fail("Schema: levels enum missing L4/L5")
        for key in ["style","themes","quotes","motifs","text_map","features"]:
            if key not in sch["properties"]: fail(f"Schema: missing property '{key}'")

    check_markers("validation/sbf_validate.py", ["rule_main_profile", "rule_l4_caps", "rule_l5_coverage", "rule_beats_tbl_columns"])
    check_markers("tools/sbf_pack.py", ["compact_pool", "--profile", "to-l3"])
    check_markers("ingest/sbf_ingest_srl.py", ["SRL-lite", "CANON"])

    for ex in ["examples/example_L4.json", "examples/example_L5.json"]:
        p = check_exists(ex, 10)
        if p:
            obj = json.loads(p.read_text(encoding="utf-8"))
            lvl = obj.get("l")
            if ex.endswith("L4.json") and lvl != "L4": fail(f"{ex}: expected l=L4, got {lvl}")
            if ex.endswith("L5.json") and lvl != "L5": fail(f"{ex}: expected l=L5, got {lvl}")

    check_markers("types/sbf.ts", ['"L4"', '"L5"', "export type SbfDoc"])
    check_markers(".github/workflows/validate.yml", ["python-validate", "types", "integrity"])
    check_markers("Makefile", ["validate", "ingest-demo", "pack-demo"])
    check_markers("LICENSE.md", ["CC BY-SA 4.0", "Apache License 2.0"])

    if FAILS:
        print(f"\nIntegrity check failed with {len(FAILS)} issue(s).")
        for i,m in enumerate(FAILS,1):
            print(f"{i}. {m}")
        sys.exit(1)
    print("\nIntegrity check passed.")
    sys.exit(0)

if __name__ == "__main__":
    main()
