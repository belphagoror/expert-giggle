<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Story Blueprint Format (SBF)

- Vision: `docs/VISION.md`
- Spec (GFM): `docs/Story_Blueprint_Format_GFM.md`
- Normative spec: `docs/SBF_v0.1_Spec.md`

## Quick start
```bash
python validation/list_sbf_files.py examples/*.json > sbf_files.txt
python validation/schema_check.py schema/sbf_schema_v0_1.json $(cat sbf_files.txt)
python validation/sbf_validate.py $(cat sbf_files.txt)

cd Project/types && npm install --no-audit --no-fund && npx tsc --noEmit
```
