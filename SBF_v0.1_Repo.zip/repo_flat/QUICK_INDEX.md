<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Quick File Index
- Vision & Principles: (sandbox:/mnt/data/docs/VISION.md)
- SBF v0.1 Spec (normative): (sandbox:/mnt/data/docs/SBF_v0.1_Spec.md)
- Spec (GFM guide): (sandbox:/mnt/data/docs/Story_Blueprint_Format_GFM.md)
- CI Workflow: (sandbox:/mnt/data/.github/workflows/validate.yml)
- Schema: (sandbox:/mnt/data/schema/sbf_schema_v0_1.json)
- Validator: (sandbox:/mnt/data/validation/sbf_validate.py)
- TypeScript types: (sandbox:/mnt/data/types/sbf.ts)
- Integrity check: (sandbox:/mnt/data/validation/integrity_check.py)
