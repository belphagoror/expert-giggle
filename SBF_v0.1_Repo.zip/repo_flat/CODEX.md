<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Using SBF with Code Assistants

## Standing instructions
- Read `docs/VISION.md` and `docs/SBF_v0.1_Spec.md` first.
- Respect level rules (L2/L3 lossy defaults).
- Run `make validate` after changes.

## Kickoff prompt
> Read the vision/spec, run `make validate`, propose the smallest improvement to SRL-lite without increasing size, update/add an example under `Project/examples`, re-run validation, and show only the diff.

## Guardrails
- Keep dependencies small; prefer pure Python.
