<!-- SPDX-License-Identifier: CC-BY-4.0 -->
# Licenses

- **Documentation & Specs**: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).
  See https://creativecommons.org/licenses/by-sa/4.0/

- **Code (tools, validators, scripts, examples code)**: Apache License 2.0.
  See https://www.apache.org/licenses/LICENSE-2.0
